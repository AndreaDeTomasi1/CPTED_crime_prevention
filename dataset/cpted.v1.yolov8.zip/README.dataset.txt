# cpted_master > 2026-01-14 7:45pm
https://universe.roboflow.com/ai-and-computer-vision-uqlm0/cpted_master

Provided by a Roboflow user
License: CC BY 4.0

